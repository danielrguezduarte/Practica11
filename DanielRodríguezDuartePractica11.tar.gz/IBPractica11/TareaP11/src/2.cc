#include <iostream>
#include <fstream>
#include <string>

// Función para rotar una vocal en minúscula
char rotateVowel(char vowel) {
    switch (vowel) {
        case 'a': return 'e';
        case 'e': return 'i';
        case 'i': return 'o';
        case 'o': return 'u';
        case 'u': return 'a';
        default: return vowel;
    }
}
// Función para rotar las vocales en una cadena
std::string rotateVowels(const std::string& input) {
    std::string result = input;
    for (char& c : result) {
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            c = rotateVowel(c);
        }
    }
    return result;
}
int main(int argc, char* argv[]) {
    // Verificar la cantidad correcta de argumentos
    if (argc != 2) {
      return 1;
    }
    // Abrir el archivo
    std::ifstream inputFile(argv[1]);
    if (!inputFile) {
        std::cerr << "No se pudo abrir el archivo: " << argv[1] << std::endl;
        return 1;
    }
    // Leer el contenido del archivo
    std::string content((std::istreambuf_iterator<char>(inputFile)),
                        std::istreambuf_iterator<char>());
    // Rotar las vocales en el contenido
    std::string rotatedContent = rotateVowels(content);
    // Mostrar el contenido rotado
    std::cout << rotatedContent;
    return 0;
}
