#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

struct Transition {
    char symbol;
    unsigned int destination;
};
struct State {
    bool isAccepting;
    std::vector<Transition> transitions;
};
int main(int argc, char* argv[]) {
    // Verificar la cantidad correcta de argumentos
    if (argc != 2) {
        std::cerr << "Uso: " << argv[0] << " <input.dfa>" << std::endl;
        return 1;
    }
    // Abrir el archivo
    std::ifstream inputFile(argv[1]);
    if (!inputFile) {
        std::cerr << "No se pudo abrir el archivo: " << argv[1] << std::endl;
        return 1;
    }

    // Leer el número total de estados
    unsigned int numStates;
    inputFile >> numStates;

    // Leer el estado de arranque
    unsigned int startState;
    inputFile >> startState;

    // Leer información de los estados
    std::vector<State> states(numStates);
    for (unsigned int i = 0; i < numStates; ++i) {
        inputFile >> i >> states[i].isAccepting;

        unsigned int numTransitions;
        inputFile >> numTransitions;

        for (unsigned int j = 0; j < numTransitions; ++j) {
            Transition transition;
            inputFile >> transition.symbol >> transition.destination;
            states[i].transitions.push_back(transition);
        }
    }

    // Mostrar características del DFA
    std::cout << "|Q| = " << numStates << std::endl;
    std::cout << "q0 = " << startState << std::endl;

    // Mostrar estados de aceptación
    std::cout << "F = {";
    for (unsigned int i = 0; i < numStates; ++i) {
        if (states[i].isAccepting) {
            std::cout << i;
            if (i < numStates - 1) {
                std::cout << ", ";
            }
        }
    }
    std::cout << "}" << std::endl;

    // Mostrar funciones de transición
    for (unsigned int i = 0; i < numStates; ++i) {
        for (const auto& transition : states[i].transitions) {
            std::cout << "delta(" << i << ", " << transition.symbol << ") = " << transition.destination << std::endl;
        }
    }

    return 0;
}
