#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cctype>
// Función para contar el número de vocales en una palabra
int contarVocales(const std::string& palabra) {
  int contador = 0;
  for (char letra : palabra) {
    if (std::tolower(letra) == 'a' || std::tolower(letra) == 'e' || std::tolower(letra) == 'i' ||
            std::tolower(letra) == 'o' || std::tolower(letra) == 'u') {
            contador++;
        }
  }
    return contador;
}
// Función para contar el número de consonantes en una palabra
int contarConsonantes(const std::string& palabra) {
    int contador = 0;
    for (char letra : palabra) {
        if (std::isalpha(letra) && std::tolower(letra) != 'a' && std::tolower(letra) != 'e' &&
            std::tolower(letra) != 'i' && std::tolower(letra) != 'o' && std::tolower(letra) != 'u') {
            contador++;
        }
    }
    return contador;
}
int main(int argc, char* argv[]) {
    // Verificar la cantidad correcta de argumentos
    if (argc != 2) {
        // Salir sin imprimir nada en caso de error
        return 1;
    }
    // Abrir el archivo
    std::ifstream archivo(argv[1]);
    // Verificar si el archivo se pudo abrir
    if (!archivo.is_open()) {
        // Salir sin imprimir nada en caso de error
        return 1;
    }
    std::string palabra;
    std::string palabraMaxVocales, palabraMaxConsonantes;
    int maxVocales = 0, maxConsonantes = 0;
    // Leer palabras del archivo
    while (archivo >> palabra) {
        // Contar el número de vocales y consonantes en la palabra actual
        int numVocales = contarVocales(palabra);
        int numConsonantes = contarConsonantes(palabra);
        // Verificar si tiene más vocales que la actual máxima
        if (numVocales > maxVocales) {
            maxVocales = numVocales;
            palabraMaxVocales = palabra;
        }
        // Verificar si tiene más consonantes que la actual máxima
        if (numConsonantes > maxConsonantes) {
            maxConsonantes = numConsonantes;
            palabraMaxConsonantes = palabra;
        }
    }
    // Imprimir resultados
    std::cout << palabraMaxVocales << " " << palabraMaxConsonantes;
    // Cerrar el archivo
    archivo.close();
    return 0;
}

