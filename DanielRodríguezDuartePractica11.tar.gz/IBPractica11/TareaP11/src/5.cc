#include <iostream>
#include <fstream>
#include <string>

void cifradoXOR(std::ifstream& entrada, std::ofstream& salida, const std::string& password, char operacion) {
    char clave = password[0];
    char caracter;
    while (entrada.get(caracter)) {
        if (operacion == '+') {
            caracter = caracter ^ clave;
        } else if (operacion == '-') {
            caracter = caracter ^ clave;
        } else {
            std::cerr << "Operación no válida.\n";
            exit(EXIT_FAILURE);
        }
        salida.put(caracter);
    }
}

void cifradoCesar(std::ifstream& entrada, std::ofstream& salida, int k, char operacion) {
    char caracter;
    while (entrada.get(caracter)) {
        if (operacion == '+') {
            caracter = (caracter + k) % 256;
        } else if (operacion == '-') {
            caracter = (caracter - k + 256) % 256;
        } else {
            std::cerr << "Operación no válida.\n";
            exit(EXIT_FAILURE);
        }
        salida.put(caracter);
    }
}

int main(int argc, char* argv[]) {
    if (argc != 6) {
        std::cerr << "Número incorrecto de argumentos.\n";
        std::cerr << "Modo de uso: " << argv[0] << " fichero_entrada fichero_salida método password operación\n";
        return 1;
    }

    std::string ficheroEntrada = argv[1];
    std::string ficheroSalida = argv[2];
    int metodo = std::stoi(argv[3]);
    std::string password = argv[4];
    char operacion = argv[5][0];

    std::ifstream entrada(ficheroEntrada, std::ios::binary);
    if (!entrada.is_open()) {
        std::cerr << "Error al abrir el fichero de entrada.\n";
        return 1;
    }

    std::ofstream salida(ficheroSalida, std::ios::binary);
    if (!salida.is_open()) {
        std::cerr << "Error al abrir el fichero de salida.\n";
        return 1;
    }

    if (metodo == 1) {
        cifradoXOR(entrada, salida, password, operacion);
    } else if (metodo == 2) {
        int k = std::stoi(password);
        cifradoCesar(entrada, salida, k, operacion);
    } else {
        std::cerr << "Método no válido.\n";
        return 1;
    }

    std::cout << "Operación completada con éxito.\n";
    entrada.close();
    salida.close();

    return 0;
}
