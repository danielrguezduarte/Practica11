#include <iostream>
#include <fstream>

int main(int argc, char *argv[]) {
    // Verificar la cantidad correcta de argumentos
    if (argc != 2) {
        std::cerr << "Uso: " << argv[0] << " <nombre_del_archivo>" << std::endl;
        return 1;
    }

    // Abrir el archivo de entrada
    std::ifstream archivoEntrada(argv[1]);
    if (!archivoEntrada.is_open()) {
        std::cerr << "No se pudo abrir el archivo de entrada." << std::endl;
        return 1;
    }

    // Leer palabras del archivo y organizarlas por letra
    std::ofstream archivosLetra[26];

    std::string palabra;
    while (archivoEntrada >> palabra) {
        if (!palabra.empty() && std::isalpha(palabra[0])) {
            char letra = std::toupper(palabra[0]);
            archivosLetra[letra - 'A'] << palabra << '\n';
        }
    }

    // Cerrar archivos y el archivo de entrada
    for (auto &archivoLetra : archivosLetra) {
        archivoLetra.close();
    }
    archivoEntrada.close();

    return 0;
}

