/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * 
 *
 * @file  P65437
 * @author Daniel Rodríguez Duarte
 * @date Nov 16 2023
 * Este programa lee la entrada de dos ficheros de textos "Fichero1" y
 "Fichero 2" y lo que hace es combinar alernativamente sus contenidos es
 decir mezcla las palabras de uno con las del otro y el resulado lo da en un 
 tercer fichero de salida 
 */

#include <string>
#include <iostream> 
#include <fstream> 
#include <vector>
//En esta parte definimos los ficheros de entrada como file1 y file2 y el fichero de salida en fileSalida 

void combinarFicheros(const std::string& fichero1, const std::string& fichero2, const std::string& ficheroSalida) {
  std::ifstream file1(fichero1);
  std::ifstream file2(fichero2);
  std::ofstream fileSalida(ficheroSalida);

if (!file1.is_open() || !file2.is_open() || !fileSalida.is_open()) {
 return;
}
std::vector<std::string> palabras1, palabras2;
std::string palabra;
while (file1 >> palabra) {
 palabras1.push_back(palabra);
}
while (file2 >> palabra) {
  palabras2.push_back(palabra);
}
size_t tamanoMaximo = std::max(palabras1.size(), palabras2.size());
  for (size_t i = 0; i < tamanoMaximo; ++i) {
  if (i < palabras1.size()) {
    fileSalida << palabras1[i] << " ";
  }
    if (i < palabras2.size()) {
      fileSalida << palabras2[i] << " ";
    }
  }
    // Cerrar los archivos
    file1.close();
    file2.close();
    fileSalida.close();
}
int main() {
  std::string fichero1 = "fichero1.txt";
  std::string fichero2 = "fichero2.txt";
  std::string ficheroSalida = "fichero_salida.txt";
// Llamada a la función para combinar los archivos
  combinarFicheros(fichero1, fichero2, ficheroSalida);
return 0;
}
